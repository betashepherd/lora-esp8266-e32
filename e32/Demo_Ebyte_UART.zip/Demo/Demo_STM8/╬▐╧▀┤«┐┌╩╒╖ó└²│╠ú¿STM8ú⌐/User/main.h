#ifndef _MAIN_H_
#define _MAIN_H_

#include "Board.h"
#include "stm8l10x_conf.h"

#endif